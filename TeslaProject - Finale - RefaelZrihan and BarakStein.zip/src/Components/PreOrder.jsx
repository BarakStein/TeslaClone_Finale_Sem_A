export default class PreOrder {
  constructor(colorDes, tireDes, totalP, imgFrontOrd, imgSideOrd, imgBackOrd) {
    this.colorDes = colorDes;
    this.tireDes = tireDes;
    this.totalP = totalP;
    this.imgFrontOrd = imgFrontOrd;
    this.imgSideOrd = imgSideOrd;
    this.imgBackOrd = imgBackOrd;
  }
}
