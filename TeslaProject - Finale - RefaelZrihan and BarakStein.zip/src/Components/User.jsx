export default class User {
  constructor(email, name, pass, address) {
    this.email = email;
    this.name = name;
    this.pass = pass;
    this.address = address;
  }
}
