export default class TestDriveC {
  constructor(email, name, phoneNumber, address) {
    this.email = email;
    this.name = name;
    this.phoneNumber = phoneNumber;
    this.address = address;
  }
}
